// const express = require('express');
// const dotenv = require('dotenv');

// dotenv.config();
// const app = express();

// const server = require('http').createServer(app);
// const io = require('socket.io')(server);

// io.on('connection', client => {
//     console.log(`connection recieved`);
//     client.on('new_message', (chat) => {
//         console.log(`new message recieved: ${chat}`)
//         io.emit('broadcast', chat)
//     })
// })

// app.get('/', (req, res) => {
//     res.send('Server is running')
// });


// const port = process.env.PORT || 3000;
// // const port = process.env.PORT;

// server.listen(port, () => {
//     console.log(`server running at ${port}...`)
// })


const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const http = require('http');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server);

// Serve static files (like index.html) from "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Serve index.html on root path
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Socket.IO logic
io.on('connection', client => {
    console.log('Connection received');

    client.on('new_message', (chat) => {
        console.log(`New message received: ${chat}`);
        io.emit('broadcast', chat);
    });
});

// Start the server
const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
